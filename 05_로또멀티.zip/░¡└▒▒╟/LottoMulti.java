import java.util.*;
import java.io.*;

class LottoMulti {
   FileReader fr;
   BufferedReader b = new BufferedReader(new InputStreamReader(System.in));
   BufferedReader br;
   Hashtable<Integer, String> ht = new Hashtable<Integer, String>();
   TreeSet<String> ts = new TreeSet<String>();
   Random r = new Random();
   int i;
   String fName = "0.txt";

   void searchFile() {
      try {
         p("����Ʈ ����(�⺻: �츮�ݸ���Ʈ.txt): ");
		 fName = b.readLine();
		 fName = fName.trim();
	  } catch(IOException e1) {
	  }
	  try {
         if(fName.length()==0)
			 fName = "�츮�ݸ���Ʈ.txt";
         fr = new FileReader(fName);
         br = new BufferedReader(fr);
      } catch(FileNotFoundException e2) {
         pln("�ش� ������ ã�� �� �����ϴ�.");
         searchFile();
      }
   }
   void input() {
      String line = "";
      try {
         while((line=br.readLine())!=null) {
            ht.put(i, line);
            i++;
         }
      } catch(IOException e1) {
      } 
   }
   int castlotsNum() {
      int num = 0;
      try {
         p("��÷�� ��: ");
         String number = b.readLine();
         number = number.trim();
         num = Integer.parseInt(number);
         if(num<=0 || num>ht.size()) {
            pln("1���� " + ht.size() + "������ ���ڸ� �Է��� �ּ���.");
            castlotsNum();
         }
      } catch(IOException e1) {
      } catch(NumberFormatException e3) {
         pln("1���� " + ht.size() + "������ ���ڸ� �Է��� �ּ���.");
         castlotsNum();
      }
      return num;
   }
   void castlots(int num) {
      int j = 0;
      String s = String.valueOf(i);
      int digit = s.length();
      while(ts.size()<num) {
         j = r.nextInt(ht.size());
         ts.add("��ȣ: " + String.format("%0"+digit+"d", (j+1)) + ", �̸�: " + ht.get(j));
      }
      Iterator<String> ir = ts.iterator();
      while(ir.hasNext()) {
         pln(ir.next());
      }
   }
   void pln(String str) {
      System.out.println(str);
   }
   void p(String str) {
      System.out.print(str);
   }
   public static void main(String args[]) {
      LottoMulti lt = new LottoMulti();
      lt.searchFile();
      lt.input();
      lt.castlots(lt.castlotsNum());
   }
}