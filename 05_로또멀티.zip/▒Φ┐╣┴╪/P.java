class P {
	static void p(String str) {
		System.out.print(str);
	}
}