import java.io.*;
import java.util.*;

class ReadCount {
	Hashtable<Integer, String> ReadList(FileReader fr){
		Hashtable<Integer, String> ht = new Hashtable<Integer, String>();
		BufferedReader br = new BufferedReader(fr);
		try {
			int i = 0; 
			String line = "";
			while((line = br.readLine()) != null) {
				ht.put(i, line);
				i++;
			}
		return ht;
		} catch(IOException ie) {
		} return ht;
	}
	TreeSet<Integer> SelectWinner(Hashtable<Integer, String> list){
		Info input= new Info();
		System.out.print("��÷�ڼ� : ");
		int winnerNumber = input.input(list.size());
		while(winnerNumber>list.size()) winnerNumber = input.input(list.size());
		TreeSet<Integer> Winners = new TreeSet<Integer>();
		while(Winners.size()<winnerNumber) {
			Winners.add(m(list.size()));
		}
		return Winners;
	}

	int m(int n) {
		Random r = new Random();
		int i = r.nextInt(n);
		return i;
	}
}