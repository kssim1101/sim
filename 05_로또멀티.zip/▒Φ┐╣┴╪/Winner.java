import java.util.*;

class Winner {
	void PrintWinner(Hashtable<Integer,String> ReadCount, TreeSet<Integer> Winner) {
		for (int i :Winner)	{
			System.out.println("��ȣ : "+String.format("%02d", i)+", �̸� : "+ReadCount.get(i));
		}
	}
}