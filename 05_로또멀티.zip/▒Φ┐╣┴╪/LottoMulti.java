import java.io.*;
import java.util.*;

class LottoMulti {
	public static void main(String[] args) {
		ReadPath file = new ReadPath();
		String FileName = file.GetFileName();
		FileReader fr = file.GetFileReader(FileName);
		ReadCount sl = new ReadCount();
		Hashtable<Integer, String> list = sl.ReadList(fr);
		TreeSet<Integer> winner = sl.SelectWinner(list);
		Winner p = new Winner();
		p.PrintWinner(list,winner);	
	}
}