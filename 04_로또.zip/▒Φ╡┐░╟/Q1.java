import java.io.*;
import java.util.*;

class Q1 
{	String fName = "�츮��.txt";
	FileReader fr;
	BufferedReader br;
	Random r = new Random();
	Vector<String> v = new Vector<String>();
	
	Q1(){
		try{
			fr = new FileReader(fName);
			br = new BufferedReader(fr);
		}catch(FileNotFoundException fe){
			pln(fName+" <-�̷� ���� �� ã��");
		}
	}
	void look(){
		try{
		int i = 0;
		String name = "";
		
		while((name = br.readLine()) != null){
			v.add(name);
			i++;
		}
		if(i == 0){
			pln("����� ��� �ֽ��ϴ�.");
			return;
		}	
		int b = r.nextInt(i);
		String win = v.get(b);
		pln("--------------------");
		pln("���ο� :" + i);
		pln("��÷�� :" + (b+"�� " +win ));
		
	}catch(IOException ie){
		ie.printStackTrace();
	}
	}

	void pln(String str){
		System.out.println(str);
	}

	public static void main(String[] args) 
	{
		Q1 q = new Q1();
		q.look();
	}
}
