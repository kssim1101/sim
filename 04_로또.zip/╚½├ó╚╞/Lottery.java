import java.util.*;
import java.io.*;
import java.util.Random;

class Lottery
{
	public static void main(String[] args) 
	{
		ReadList r = new ReadList();
		Hashtable ht = r.getHashtable();
		int i= new Ran().m(ht.size());
		System.out.println("��÷�ڴ� "+ht.get(i));
		ReadList r1 = new ReadList();
		Vector v = r1.getVector();
		int i1= new Ran().m(v.size());
		System.out.println("��÷�ڴ� "+v.get(i1));
		ReadList r2 = new ReadList();
		String strs[]= r2.getStringArray();
		int i2= new Ran().m(strs.length);
		System.out.println("��÷�ڴ� "+strs[i2]);

	}
}

class ReadList 
{
	String fName = "�츮��.txt";
	FileReader fr;
	BufferedReader br;

	ReadList(){
		try{
			fr = new FileReader(fName);
			br = new BufferedReader(fr);
			//pln(fName+"������ ã��");
		}catch(FileNotFoundException fe){
			System.out.println(fName+"�̶� ������ ��ã��");
		}
	}
	
	Hashtable getHashtable(){
		Hashtable<Integer, String> ht = new Hashtable<Integer, String>();
		try{
			int i = 0; 
			String line = "";
			while((line = br.readLine()) != null){
				ht.put(i, line);
				i++;
			}
			return ht;
		}catch(IOException ie){
		}
		return ht;
	}
	Vector getVector(){
		Vector<String> v = new Vector<String>();
		try{
			int i = 0; 
			String line = "";
			while((line = br.readLine()) != null){
				v.add(line);
				i++;
			}
			return v;
		}catch(IOException ie){
		}
		return v;
	}
	String[] getStringArray(){
		int i = 0; 
		try{
			String line = "";
			while((line = br.readLine()) != null){
				i++;
			}
		}catch(IOException ie){
		}
		String st[] = new String[i];
		try{
			fr = new FileReader(fName);
			br = new BufferedReader(fr);
			//pln(fName+"������ ã��");
		}catch(FileNotFoundException fe){
			System.out.println(fName+"�̶� ������ ��ã��");
		}
		try{
			BufferedReader br1 = new BufferedReader(fr);
			i = 0; 
			String line = "";
			while((line = br1.readLine()) != null){
				st[i]=line;
				i++;
			}
			return st;
		}catch(IOException ie){
		}
		return st;
	}
}

class Ran  
{
	int m(int n){
		Random r = new Random();
		int i = r.nextInt(n);
		return i;
	}
}