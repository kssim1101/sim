import java.io.*;

class ReadList 
{
	String fName = "�츮��.txt";
	FileReader fr;
	BufferedReader br;

	ReadList(){
		try{
			fr = new FileReader(fName);
			br = new BufferedReader(fr);
			//pln(fName+"������ ã��");
		}catch(FileNotFoundException fe){
			pln(fName+"�̶� ������ ��ã��");
		}
	}
	void show(){
		try{
			int i = 0; 
			String line = "";
			while((line = br.readLine()) != null){
				pln(i + ": " + line);
				i++;
			}
			pln("-----------------------");
			pln("���ο�: " + i);
		}catch(IOException ie){}
	}
	void pln(String str){
		System.out.println(str);
	}
	public static void main(String[] args) 
	{
		ReadList r = new ReadList();
		r.show();
	}
}
