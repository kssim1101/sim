import java.util.Random;

class Ran  
{
	Random r = new Random();
	int n = 3;
	void m(){
		int i = r.nextInt(n);//0 ~ (n-1)
		System.out.println("i: " + i);
	}
	public static void main(String[] args) {
		Ran ran = new Ran();
		ran.m();
	}
}
