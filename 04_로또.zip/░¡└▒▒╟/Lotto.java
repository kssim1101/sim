import java.util.*;
import java.io.*;

class Lotto {
	String fName = "�츮��.txt";
	FileReader fr;
	BufferedReader br;
	Vector<String> v = new Vector<String>();
	Random r  = new Random();
	Lotto() {
		try {
			fr = new FileReader(fName);
			br = new BufferedReader(fr);
		} catch(FileNotFoundException v2) {
			pln("/'" + fName + "/' ������ ã�� �� �����ϴ�.");
		}
	}
	void show () {
		String line = "";
		try{
			while((line=br.readLine())!=null) {
				v.add(line);
			}
		} catch(IOException v1) {
		}
	}
	void ran() {
		int j = r.nextInt(v.size());
		System.out.println("��÷��: " + v.get(j));
	}
	void pln(String str) {
		System.out.println(str);
	}
	public static void main(String args[]) {
		Lotto l = new Lotto();
		l.show();
		l.ran();
	}
}