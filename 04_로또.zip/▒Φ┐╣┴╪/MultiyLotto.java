import java.io.*;
import java.util.*;

class MultiyLotto
{
	String fName = "�츮��.txt";
	FileReader fr;
	BufferedReader br;
	Vector<String> v = new Vector<String>();
	Random r = new Random();

	MultiyLotto(){
		try{
			fr = new FileReader(fName);
			br = new BufferedReader(fr);
			//pln(fName+"������ ã��");
		}catch(FileNotFoundException fe){
			pln(fName+"�̶� ������ ��ã��");
		}
	}
	String show(){
		String line = "";
		try{
			int i = 0;
			while((line = br.readLine()) != null){
				//pln(i + ": " + line);
				v.add(line);
				i++;
			}
			//pln("-----------------------");
			//pln("���ο�: " + i);
			return line;
		}catch(IOException ie){
			return show();
		}
	}
	void ran(){
		int i = r.nextInt(v.size());
		System.out.println("��÷��: " + v.get(i));
	}
	void pln(String str){
		System.out.println(str);
	}
	public static void main(String[] args)
	{
		MultiyLotto l = new MultiyLotto();
		l.show();
		l.ran();
	}
}